//package com.example.WWE.Controller;
//
//import com.example.WWE.Model.Dto;
//import com.example.WWE.Service.DtoService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/dto")
//public class DtoController {
//    @Autowired
//    private DtoService dtoService;
//
//    @GetMapping
//    public List<Dto> getDto(){
//        return dtoService.getDto();
//    }
//    @GetMapping("/{id}")
//    public ResponseEntity<Dto> getDtoById(@PathVariable Long id){
//         dtoService.getDtoById(id);
//        return new ResponseEntity<>(HttpStatus.OK);
//    }
//    @PostMapping
//    public Dto CreateDto(@RequestBody Dto dto){
//        return dtoService.saveDtoByName(dto);
//    }
//    @PutMapping("/{id}")
//    public ResponseEntity<Dto> AddDto(@PathVariable Long id, @RequestBody Dto dto){
//        try{
//           Dto dto1 = dtoService.createDtoByNameAndId(id, dto);
//            return new ResponseEntity<>(dto1, HttpStatus.OK);
//        }catch (RuntimeException e){
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT );
//        }
//    }
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Dto> deleteById(@PathVariable Long id){
//        if (dtoService.deleteDtoById(id)) {
//            dtoService.deleteDtoById(id);
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT );
//        }else {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//    }
//}
