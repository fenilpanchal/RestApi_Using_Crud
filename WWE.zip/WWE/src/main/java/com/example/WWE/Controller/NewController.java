//package com.example.WWE.Controller;
//
//import com.example.WWE.Model.UserIsNew;
//import com.example.WWE.Service.NewService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/happy")
//public class NewController {
//    private NewService newService;
//    @Autowired
//    public NewController (NewService newService){
//        this.newService =newService;
//    }
//
//    @GetMapping
//    public List<UserIsNew> getUser(){
//        return newService.getUser();
//    }
//    @GetMapping("/{id}")
//    public ResponseEntity<UserIsNew> getUserById(@PathVariable Long id){
//        UserIsNew userIsNew = newService.getUserById(id).orElseThrow();
//        return new ResponseEntity(userIsNew,HttpStatus.OK);
//    }
//
//    @PostMapping
//    public UserIsNew createUser(@RequestBody UserIsNew userIsNew ){
//        return newService.addUserByName(userIsNew);
//    }
//
//    @PutMapping("/{id}")
//    public ResponseEntity<UserIsNew> updateUser( @PathVariable Long id,@RequestBody UserIsNew userIsNew ){
//        try {
//           UserIsNew userIsNew1 = newService.updateUser(id, userIsNew);
//            return new ResponseEntity<>(userIsNew1,HttpStatus.OK);
//        }catch (RuntimeException e){
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//        }
//    }
//      @DeleteMapping("/{id}")
//      public ResponseEntity<UserIsNew> deleteUser(@PathVariable Long id) {
//       UserIsNew userIsNew = newService.deleteUser(id);
//       return new ResponseEntity<>( userIsNew,HttpStatus.OK);
//     }
//}
