//package com.example.WWE.Service;
//
//import com.example.WWE.Model.Omg;
//import com.example.WWE.Repository.OmgRepo;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class OmgService {
//    private OmgRepo omgRepo;
//
//    @Autowired
//    public OmgService (OmgRepo omgRepo){
//        this.omgRepo=omgRepo;
//    }
//    //1
//    public List<Omg> getOmg(){
//        return omgRepo.findAll();
//    }
//
//    //2
//    public Optional<Omg> getOmgById(Long id){
//        return omgRepo.findById(id);
//    }
//
//    //3
//    public Omg createOmg(Omg omg){
//        return omgRepo.save(omg);
//    }
//
//    //4
//    public Omg updateOmg(Long id,Omg omg){
//       Omg myNewApp = omgRepo.findById(id).orElseThrow();
//        myNewApp.setName(omg.getName());
//        myNewApp.setNumber(omg.getNumber());
//        return omgRepo.save(myNewApp);
//    }
//    //5
//    public boolean deleteOmg(Long id){
//        omgRepo.deleteById(id);
//        return true;
//    }
//}
