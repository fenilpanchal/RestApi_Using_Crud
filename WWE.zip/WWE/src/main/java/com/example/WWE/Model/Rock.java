//package com.example.WWE.Model;
//
//import jakarta.persistence.*;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Entity
//@AllArgsConstructor
//@NoArgsConstructor
//@Table(name = "std")
//@Data
//
//public class Rock {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id ;
//
//    @Column(nullable = false)
//    private String name;
//
//    @Column(nullable = false,unique = true)
//    private String email;
//
//    private double fee;
//
//}
