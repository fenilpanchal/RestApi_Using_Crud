//package com.example.WWE.Repository;
//
//import com.example.WWE.Model.Rock;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface NewR extends JpaRepository<Rock,Long> {
//
//
//}
