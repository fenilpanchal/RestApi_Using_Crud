package com.example.WWE.Controller;

import com.example.WWE.Model.Demo;
import com.example.WWE.Service.StudentDemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentDemoService studentDemoService;

    @GetMapping
    public List<Demo> getStudent(){
        return studentDemoService.getStudentDemo();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Demo> gerStudentById(@PathVariable Long id){
        studentDemoService.getStudentDemoById(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping
    public Demo addStudentByName(@RequestBody Demo demo){
        return studentDemoService.addStudentDemoByName(demo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Demo> updateStudent(@PathVariable Long id,@RequestBody Demo demo){
        try {
            Demo demo1 = studentDemoService.updateStudentDemoById(id,demo);
            return new ResponseEntity<>(demo1, HttpStatus.OK);
        }catch (RuntimeException e){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity <Demo> deleteStudent(@PathVariable Long id){
        if (studentDemoService.deleteStudentDemoById(id)) {
            studentDemoService.deleteStudentDemoById(id);
            return new ResponseEntity <>(HttpStatus.NO_CONTENT);
        }else {
            return new ResponseEntity <>(HttpStatus.NOT_FOUND );
        }

    }

}