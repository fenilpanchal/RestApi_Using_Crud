package com.example.WWE.Service;

import com.example.WWE.Model.Demo;
import com.example.WWE.Repository.StudentDemoRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentDemoService {
    @Autowired
    private StudentDemoRepo studentDemoRepo;

    public List<Demo> getStudentDemo(){
        return studentDemoRepo.findAll();
    }

    public Optional<Demo> getStudentDemoById(Long id){
       return studentDemoRepo.findById(id);
    }

    public Demo addStudentDemoByName(Demo demo){
        return studentDemoRepo.save(demo);
    }

    public Demo updateStudentDemoById(Long id,Demo demo){
        Demo demo1 = studentDemoRepo.findById(id).orElseThrow();
         demo1.setName(demo.getName());
         demo1.setEmail(demo.getEmail());
         demo1.setBranch(demo.getBranch());
         demo1.setAddress(demo.getAddress());
         demo1.setEnNumber(demo.getEnNumber());
        return studentDemoRepo.save(demo1);
    }

    public boolean deleteStudentDemoById(Long id){
        studentDemoRepo.deleteById(id);
        return true;
    }
}
