//package com.example.WWE.Service;
//
//import com.example.WWE.Model.UserIsNew;
//import com.example.WWE.Repository.UserRepo;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class NewService {
//
//    @Autowired
//    private UserRepo userRepo;
//
//    public List<UserIsNew> getUser(){
//       return userRepo.findAll();
//
//    }
//
//    public Optional<UserIsNew> getUserById(Long id){
//        return userRepo.findById(id);
//    }
//
//    public UserIsNew addUserByName(UserIsNew user){
//       return userRepo.save(user);
//    }
//
//    public UserIsNew updateUser(Long id ,UserIsNew userIsNew2){
//        return userRepo.findById(id).map(userIsNew ->{
//            userIsNew.setName(userIsNew2.getName());
//            userIsNew.setAddress(userIsNew2.getAddress());
//            return userRepo.save(userIsNew);
//        } ).orElseThrow(()-> new RuntimeException("not found"+id) );
//    }
//    public UserIsNew deleteUser(Long id){
//        userRepo.deleteById(id);
//        return null;
//    }
//}
