//package com.example.WWE.Service;
//
//import com.example.WWE.Model.Rock;
//import com.example.WWE.Repository.NewR;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//
//public class UserService {
//    @Autowired
//    private NewR newR;
//
//    public List<Rock> getUser(){
//        return newR.findAll();
//    }
//
//    public Optional<Rock> getUserById(Long id){
//        return newR.findById(id);
//    }
//
//    public Rock saveUser(Rock rock){
//        return newR.save(rock);
//    }
//
//    public Rock updateUser(Long id, Rock rock){
//        Rock r = newR.findById(id).orElseThrow();
//        r.setName(rock.getName());
//        r.setEmail(rock.getEmail());
//        r.setFee(rock.getFee());
//        return newR.save(r);
//    }
//
//    public Rock deleteUserById(Long id){
//        newR .deleteById(id);
//        return null;
//    }
//}
