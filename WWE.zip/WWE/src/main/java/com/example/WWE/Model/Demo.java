package com.example.WWE.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "f1")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Demo {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Enrolment",nullable = false)
    private int enNumber;

    @Column (name = "Name",nullable = false)
    private String name;

    @Column (name = "Email",nullable = false,unique = true)
    private String email;

    @Column (name = "Branch",nullable = false)
    private String branch;

    @Column (name = "Address")
    private String address;
}
