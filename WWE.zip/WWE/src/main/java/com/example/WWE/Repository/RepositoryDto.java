//package com.example.WWE.Repository;
//
//import com.example.WWE.Model.Dto;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface RepositoryDto extends JpaRepository<Dto,Long> {
//
//}
