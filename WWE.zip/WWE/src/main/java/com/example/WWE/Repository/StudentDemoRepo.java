package com.example.WWE.Repository;

import com.example.WWE.Model.Demo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentDemoRepo extends JpaRepository<Demo,Long> {

}
