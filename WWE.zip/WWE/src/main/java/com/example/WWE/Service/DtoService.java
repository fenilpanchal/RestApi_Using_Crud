//package com.example.WWE.Service;
//
//import com.example.WWE.Model.Dto;
//import com.example.WWE.Repository.RepositoryDto;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class DtoService {
//    @Autowired
//    private RepositoryDto repositoryDto;
//
////    public DtoService(RepositoryDto repositoryDto){
////        this.repositoryDto=repositoryDto;
////    }
//
//    public List<Dto> getDto(){
//        return repositoryDto.findAll();
//    }
//    public Optional<Dto> getDtoById(Long id){
//        return repositoryDto.findById(id);
//    }
//    public Dto saveDtoByName(Dto dto){
//        return repositoryDto.save(dto);
//    }
//    public Dto createDtoByNameAndId(Long id ,Dto dto){
//        return repositoryDto.findById(id).map(dto1 -> {
//            dto1.setName(dto.getName());
//            dto1.setEmail(dto.getEmail());
//            dto1.setSalary(dto.getSalary());
//            return repositoryDto.save(dto1);
//        }).orElseThrow(()-> new RuntimeException("not found"+id));
//    }
//    public boolean deleteDtoById(Long id){
//        repositoryDto.deleteById(id);
//        return true;
//    }
//}
