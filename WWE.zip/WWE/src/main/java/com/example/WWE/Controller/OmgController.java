//package com.example.WWE.Controller;
//
//import com.example.WWE.Model.Omg;
//import com.example.WWE.Service.OmgService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/omg/table")
//public class OmgController {
//    private OmgService omgService;
//
//    @Autowired
//    public OmgController (OmgService omgService){
//        this.omgService=omgService;
//    }
//
//    @GetMapping
//    public List<Omg> getOmg(){
//        return omgService.getOmg();
//    }
//
//    @GetMapping ("/{id}")
//    public ResponseEntity<Omg> getOmgById(@PathVariable Long id){
//       return omgService.getOmgById(id)
//                .map(ResponseEntity::ok)
//                .orElse( ResponseEntity.notFound().build());
//    }
//
//    @PostMapping
//    public Omg createOmg(@RequestBody Omg omg){
//        return omgService.createOmg(omg);
//    }
//
//    @PutMapping("/{id}")
//    public ResponseEntity <Omg> updateOmg(@PathVariable Long id,@RequestBody Omg omg){
//        try {
//           Omg omg1 = omgService.updateOmg(id,omg);
//            return new ResponseEntity<>( omg1, HttpStatus.OK);
//        }catch (RuntimeException e){
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//        }
//    }
//    @DeleteMapping("/{id}")
//    public ResponseEntity <Void> deleteOmg(@PathVariable Long id){
//        if (omgService.deleteOmg(id)) {
//            omgService.deleteOmg(id);
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//        } else {
//            return new ResponseEntity<>(HttpStatus .NOT_FOUND);
//        }
//    }
//}
